from pydantic import BaseModel, EmailStr, Field
from typing import Optional

class LoginRequest(BaseModel):
    email: EmailStr
    password: str

class LoginResponse(BaseModel):
    success: bool
    message: str

class ProductIn(BaseModel):
    name: str = Field(..., min_length=1)
    price: float = Field(..., gt=0)

class ProductOut(BaseModel):
    id: str
    name: str
    price: float

class ProductListResponse(BaseModel):
    success: bool
    data: list[ProductOut]

class ProductAddResponse(BaseModel):
    success: bool
    message: str

from fastapi import FastAPI, HTTPException, status, Depends
from fastapi.middleware.cors import CORSMiddleware
from pymongo.errors import PyMongoError
from datetime import datetime
from models import LoginRequest, LoginResponse, ProductIn, ProductOut, ProductListResponse, ProductAddResponse
from database import products_collection, product_doc_to_dict
from auth import authenticate_user

app = FastAPI()

# Allow CORS for all origins (for development)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.post("/api/login", response_model=LoginResponse)
def login(payload: LoginRequest):
    if authenticate_user(payload.email, payload.password):
        return {"success": True, "message": "Login successful"}
    raise HTTPException(status_code=401, detail="Invalid email or password")

@app.get("/api/products", response_model=ProductListResponse)
def get_products():
    products = [product_doc_to_dict(doc) for doc in products_collection.find()]
    return {"success": True, "data": products}

@app.post("/api/products", response_model=ProductAddResponse, status_code=201)
def add_product(product: ProductIn):
    try:
        doc = product.dict()
        doc["createdat"] = datetime.utcnow()
        result = products_collection.insert_one(doc)
        if result.inserted_id:
            return {"success": True, "message": "Product added successfully"}
        else:
            raise HTTPException(status_code=400, detail="Database insertion failed")
    except PyMongoError:
        raise HTTPException(status_code=400, detail="Invalid product data")

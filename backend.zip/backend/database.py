import os
from pymongo.mongo_client import MongoClient
from pymongo.server_api import ServerApi
from dotenv import load_dotenv


load_dotenv()

MONGODB_URI = os.getenv("MONGODB_URI", "mongodb+srv://milind123:milind@2026@cluster0.np1h41w.mongodb.net/?appName=Cluster0")
DB_NAME = os.getenv("DB_NAME", "product_management")

client = MongoClient(MONGODB_URI, server_api=ServerApi('1'))
db = client[DB_NAME]
products_collection = db["products"]

# Helper to convert MongoDB document to dict with string id
def product_doc_to_dict(doc):
    return {
        "id": str(doc["_id"]),
        "name": doc["name"],
        "price": doc["price"]
    }

# Optional: Ping to confirm connection at startup
try:
    client.admin.command('ping')
    print("Pinged your deployment. You successfully connected to MongoDB!")
except Exception as e:
    print(e)

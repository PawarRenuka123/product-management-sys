from fastapi import HTTPException
from pydantic import EmailStr

# For demo: hardcoded user
USERS = {
    "user@example.com": {
        "password": "Password123"
    }
}

def authenticate_user(email: EmailStr, password: str):
    user = USERS.get(email)
    if user and user["password"] == password:
        return True
    return False

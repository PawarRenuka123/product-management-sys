import 'package:http/http.dart' as http;
import 'dart:convert';

class ApiService {
  // Use only the base URL (no /login at the end)
  static const String baseUrl = "http://10.115.92.183:8000/api";


  // ✅ Login
  static Future<Map<String, dynamic>> login(
    String email,
    String password,
  ) async {
    try {
      final response = await http
          .post(
            Uri.parse('$baseUrl/login'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({'email': email, 'password': password}),
          )
          .timeout(const Duration(seconds: 30));

      return jsonDecode(response.body);
    } catch (e) {
      return {'success': false, 'message': 'Network error: ${e.toString()}'};
    }
  }

  // ✅ Get products
  static Future<List<dynamic>> getProducts() async {
    try {
      final response = await http
          .get(
            Uri.parse('$baseUrl/products'),
            headers: {'Content-Type': 'application/json'},
          )
          .timeout(const Duration(seconds: 15));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['data'] ?? [];
      } else {
        throw Exception('Failed to load products');
      }
    } catch (e) {
      throw Exception('Network error: ${e.toString()}');
    }
  }

  // ✅ Add product
  static Future<Map<String, dynamic>> addProduct(
    String name,
    double price,
  ) async {
    try {
      final response = await http
          .post(
            Uri.parse('$baseUrl/products'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({'name': name, 'price': price}),
          )
          .timeout(const Duration(seconds: 30));

      return jsonDecode(response.body);
    } catch (e) {
      return {'success': false, 'message': 'Network error: ${e.toString()}'};
    }
  }
}

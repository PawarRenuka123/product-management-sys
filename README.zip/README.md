# Product Management System

## Overview
This repository contains a Flutter mobile app and a FastAPI backend for a simple product management system with MongoDB integration.

---

## Backend (FastAPI + MongoDB)

### Setup Steps
1. **Clone the repository or unzip the project.**
2. **Navigate to the backend folder:**
   ```sh
   cd backend
   ```
3. **Create and activate a virtual environment (optional but recommended):**
   ```sh
   python -m venv .venv
   # On Windows:
   .venv\Scripts\activate
   # On Mac/Linux:
   source .venv/bin/activate
   ```
4. **Install dependencies:**
   ```sh
   pip install -r requirements.txt
   ```
5. **Configure MongoDB:**
   - Create a `.env` file in the `backend` folder:
     ```
     MONGODB_URI=mongodb+srv://<username>:<password>@<cluster-url>/?appName=<appName>
     DB_NAME=product_management
     ```
   - Replace with your actual MongoDB Atlas credentials.
6. **Run the backend server:**
   ```sh
   uvicorn main:app --host 0.0.0.0 --port 8000 --reload
   ```

### API Endpoints
- **POST /api/login**
  - Request: `{ "email": "user@example.com", "password": "Password123" }`
  - Success: `{ "success": true, "message": "Login successful" }`
  - Failure: `{ "success": false, "message": "Invalid email or password" }`

- **GET /api/products**
  - Response: `{ "success": true, "data": [ { "id": "...", "name": "...", "price": ... } ] }`

- **POST /api/products**
  - Request: `{ "name": "Product Name", "price": 123.45 }`
  - Success: `{ "success": true, "message": "Product added successfully" }`
  - Failure: `{ "success": false, "message": "Invalid product data" }`

---

## Mobile App (Flutter)

### Setup Steps
1. **Navigate to the Flutter project root:**
   ```sh
   cd product_management_system
   ```
2. **Install dependencies:**
   ```sh
   flutter pub get
   ```
3. **Update API base URL:**
   - In `lib/srevices/api_service.dart`, set the `baseUrl` to your backend's IP and port (e.g., `http://10.0.2.2:8000/api` for emulator, or your PC's IP for a real device).
4. **Run the app:**
   ```sh
   flutter run
   ```

---

## Demo Video
Include a screen recording or link to a video showing login, product listing, and adding a product.

---

## Notes
- Make sure your backend and MongoDB are running and accessible from your device/emulator.
- For Android emulator, use `10.0.2.2` as the backend host. For a real device, use your computer's local IP address.
- The backend uses a hardcoded user: `user@example.com` / `Password123`.

---

## Folder Structure
- `backend/` - FastAPI backend source code
- `lib/` - Flutter app source code
- `README.md` - This file
